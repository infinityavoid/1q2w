
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'uaa1_2' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* Keil.Standalone::Device:Startup:1.0.0 */
#define USE_HAL_DRIVER
          #define USE_FULL_LL_DRIVER


#endif /* PRE_INCLUDE_GLOBAL_H */
