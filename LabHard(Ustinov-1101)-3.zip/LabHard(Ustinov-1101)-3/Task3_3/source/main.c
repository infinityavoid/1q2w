#include "main.h"

int main(void) {
  uint8_t d;
	uint8_t old;
  RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
  GPIOB->MODER |= 0x15555;
  InitUSART1();
  GPIOB->ODR |= 0x100;
  while (1) {
    while ((USART1 ->ISR & USART_ISR_RXNE) == 0) {}
    d = (uint8_t) USART1 ->RDR;
    if (!(d &0x02)) 
			{
      if ((d & 0x01) && (!(old & 0x01))) 
				{
        GPIOB->BSRR = 0x40;
        GPIOB->BSRR = 0x10;
      }
    }
		else 
		{
        GPIOB->BSRR = 0x10<<16;
				GPIOB->BSRR = 0x40<<16;
				old = d;
    }
  }
}
void InitUSART1(void) {
  RCC ->APB2ENR |= RCC_APB2ENR_USART1EN;
  RCC ->AHBENR |= RCC_AHBENR_GPIOAEN;

  GPIOA ->MODER |= 0x00280000;
  GPIOA ->AFR[1] |= 0x00000110;

  GPIOA ->OTYPER &= ~GPIO_OTYPER_OT_9;
  GPIOA ->PUPDR &= ~GPIO_PUPDR_PUPDR9;
  GPIOA ->OSPEEDR |= GPIO_OSPEEDR_OSPEEDR9;

  GPIOA ->PUPDR &= ~GPIO_PUPDR_PUPDR10;
  GPIOA ->PUPDR |= GPIO_PUPDR_PUPDR10_0;

  USART1 ->CR1 &= ~USART_CR1_UE;
  USART1 ->BRR = 69;

  USART1 ->CR1 = USART_CR1_TE | USART_CR1_RE;

  USART1 ->CR2 = 0;
  USART1 ->CR3 = 0;
  USART1 ->CR1 |= USART_CR1_UE;
}
