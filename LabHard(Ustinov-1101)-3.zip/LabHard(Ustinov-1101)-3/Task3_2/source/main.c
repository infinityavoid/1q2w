#include "main.h"

int main(void) {
  uint8_t w[] = {
    0x01,
    0x02,
    0x04,
    0x80,
    0x40,
    0x20,
    0x10,
    0x08
  };
  uint8_t q[] = {
    0x31,
    0x32,
    0x33,
    0x34,
    0x35,
    0x36,
    0x37,
    0x38
  };
  uint8_t i = 0;
  uint32_t j = 0;
  uint32_t k = 0;
  uint8_t check[] = {
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0
  };
  uint8_t d;
  RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
  GPIOB->MODER |= 0x15555;
  InitUSART1();
  GPIOB->ODR |= 0x100;
  while (1) {
    uint32_t mes1[] = {
      0,
      0x20,
      0x6f,
      0x6e,
      0x0a,
      0x0d
    };
    uint32_t mes2[] = {
      0,
      0x20,
      0x6f,
      0x66,
      0x66,
      0x0a,
      0x0d
    };
    while ((USART1->ISR & USART_ISR_RXNE) == 0) {}
    d = (uint8_t) USART1->RDR;
    //if (d >= 0x31 && d <=0x38)
    for (i = 0; i < 8; i++) {
      if (d == q[i]) //esli nazhat 1-8
      {
        if (check[i] == 0) //esli ne gorit, to zazhigaet
        {
          mes1[0] = q[i];
          check[i] = 1;
          GPIOB ->ODR |= w[i];
          for (j = 0; j < 6; j++) {
            while ((USART1 ->ISR & USART_ISR_TXE) == 0) {}
            USART1 ->TDR = mes1[j];
          }
        } else if (check[i] == 1) //esli gorit, to tushit
        {
          mes2[0] = q[i];
          check[i] = 0;
          GPIOB ->BRR |= w[i];
          for (j = 0; j < 7; j++) {
            while ((USART1 ->ISR & USART_ISR_TXE) == 0) {}
            USART1 ->TDR = mes2[j];
          }
        }
      }
    }
    i = 0;
    if (d == 0x30) {
      for (i = 0; i < 8; i++) {
        GPIOB ->BRR |= w[i];
        check[i] = 0;
      }
      for (k = 0; k < 8; k++) {
        mes1[0] = q[k];
        mes2[0] = q[k];
        if (check[k] == 0) {
          for (j = 0; j < 7; j++) {
            while ((USART1 ->ISR & USART_ISR_TXE) == 0) {}
            USART1 ->TDR = mes2[j];
          }
        } else {
          for (j = 0; j < 6; j++) {
            while ((USART1 ->ISR & USART_ISR_TXE) == 0) {}
            USART1 ->TDR = mes1[j];
          }
        }
      }
    }
    if (d == 0x39) {
      for (k = 0; k < 8; k++) {
        mes1[0] = q[k];
        mes2[0] = q[k];
        if (check[k] == 0) {
          for (j = 0; j < 7; j++) {
            while ((USART1 ->ISR & USART_ISR_TXE) == 0) {}
            USART1 ->TDR = mes2[j];
          }
        } else {
          for (j = 0; j < 6; j++) {
            while ((USART1 ->ISR & USART_ISR_TXE) == 0) {}
            USART1 ->TDR = mes1[j];
          }
        }
      }
    }
  }
}
void InitUSART1(void) {
  RCC ->APB2ENR |= RCC_APB2ENR_USART1EN;
  RCC ->AHBENR |= RCC_AHBENR_GPIOAEN;

  GPIOA ->MODER |= 0x00280000;
  GPIOA ->AFR[1] |= 0x00000110;

  GPIOA ->OTYPER &= ~GPIO_OTYPER_OT_9;
  GPIOA ->PUPDR &= ~GPIO_PUPDR_PUPDR9;
  GPIOA ->OSPEEDR |= GPIO_OSPEEDR_OSPEEDR9;

  GPIOA ->PUPDR &= ~GPIO_PUPDR_PUPDR10;
  GPIOA ->PUPDR |= GPIO_PUPDR_PUPDR10_0;

  USART1 ->CR1 &= ~USART_CR1_UE;
  USART1 ->BRR = 69;

  USART1 ->CR1 = USART_CR1_TE | USART_CR1_RE;

  USART1 ->CR2 = 0;
  USART1 ->CR3 = 0;
  USART1 ->CR1 |= USART_CR1_UE;
}
